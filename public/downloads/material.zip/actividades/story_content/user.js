function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6c6BgQSCo6g":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

